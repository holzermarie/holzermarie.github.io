function bleu() {
    console.log("on a cliqué sur le bouton");
    let element = document.getElementById("letitre");
    element.style.color = "#0000F0";
}

