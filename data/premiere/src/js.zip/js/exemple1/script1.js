function hello() {
    window.alert("Hello world!");
    console.log("on a cliqué sur le titre");
}

