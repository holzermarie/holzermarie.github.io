let n = 0;

function changeInfo() {
    console.log("La valeur de n est : ", n);
    n = n+1;
    console.log("La nouvelle valeur de n est : ", n);
    let element = document.getElementById("info");
    element.innerHTML = "Vous avez cliqué " + n + " fois sur le bouton.";
}
