function hello() {
    window.alert("Hello world!");
    console.log("on a cliqué sur le titre");
}

function bleu(element) {
    element.innerHTML = "Titre survolé";
    element.style.color = "#0000F0";
    element.style.fontSize = "48px";
}

function noir(element) {
    element.innerHTML = "Nouveau titre";
    element.style.color = "#000000";
    element.style.fontSize = "32px";
}
