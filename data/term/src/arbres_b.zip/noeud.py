# IMPORTS
from displayer import display, log
from random import randint

# CLASS
class Noeud :

    def __init__(self, val):
        """ Construit un noeud d'étiquette val sans sous-arbre """
        self.etiquette = val
        self.sag = None # sous-arbre gauche
        self.sad = None # sous-arbre droit
        
    # sert pour l'affichage
    def get_value(self):
        return self.etiquette
        
    # sert pour l'affichage
    def get_children(self):
        return [c for c in (self.sag, self.sad) if c]
        
    def taille(self):
        pass

    def hauteur(self):
        pass

    def nb_feuilles(self):
        pass



# SCRIPT
racine = Noeud("A")
log(racine)
display(racine)
