import sys
sys.path.append('../')

from modules.gmanager import display, display_from_adjacency_list

liste_adjacence = {"A" : ["B"], 
                   "B" : ["A", "C"], 
                   "C" : ["B"]}

display_from_adjacency_list(liste_adjacence)