from tkinter.filedialog import askopenfile, asksaveasfile
import json
from modules.mgraph import DGraph

class IOManager:

    def __init__(self):
        pass

    def to_dict(self, g, displayer):
        d = {}
        d["directed"] = g.directed

        nodes_d = {}
        for label, dnode in g.graph.nodes.items():
            nodes_d[label] = [child.label for child in dnode.children]
        d["adjacency_list"] = nodes_d

        nodes_p= {}
        for node in displayer.nodes:
            nodes_p[node.label] = node.center
        d["positions"] = nodes_p
        
        return d
        
    def from_dict(self, d):
        directed = d["directed"]
        adj_list = d["adjacency_list"]
        pos = d["positions"]
        g = DGraph.get_from_dict(adj_list, directed)
        return g, directed, pos

    
    def save(self, graph, displayer):
        d = self.to_dict(graph, displayer)
        j = json.dumps(d, sort_keys=True, indent=2)
        f = asksaveasfile(defaultextension=".json")
        if f is None:
            return
        f.write(j)
        f.close()

        
    def open(self):
        f = askopenfile(defaultextension=".json")
        if f is None:
            return
        js = f.read()
        f.close()
        d = json.loads(js)
        return self.from_dict(d)


