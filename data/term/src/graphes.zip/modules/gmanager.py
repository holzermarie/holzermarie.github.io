from modules.mgraph import MGraph, DGraph
from modules.gdisplayer import GDisplayer
from modules.tkcontext import TkContext
from modules.iomanager import IOManager
from modules.latexwriter import LatexWriter
import pyperclip

class GManager :

    def __init__(self, graph, directed, w, h):
        self.mgraph = MGraph(graph, directed, self)
        self.iomanager = IOManager()
        self.tk = TkContext(w, h)
        
        self.displayer = GDisplayer(self.mgraph, self.tk, w, h)
        self.displayer.draw()

        self.tk.add_menu_command(0, "Ouvrir", self.open, "Ctrl+O", "<Control-o>")
        self.tk.add_menu_command(0, "Exporter", self.save, "Ctrl+S", "<Control-s>")
        self.tk.add_menu_command(0, "Export Latex", self.latex, "Ctrl+L", "<Control-l>")
        self.tk.add_menu_command(0, "Quitter", self.quit, "Ctrl+Q", "<Control-q>")

        self.tk.mainloop()
        
    def open(self):
        op = self.iomanager.open()
        if op is None:
            return
        g, directed, pos = op
        self.mgraph = MGraph(g, directed, self)
        self.displayer.set_graph(self.mgraph, pos)
        self.displayer.draw()
        
    def save(self):
        self.iomanager.save(self.mgraph, self.displayer)

    def quit(self):
        self.tk.window.destroy()
        
    def latex(self):
        self.latexwriter = LatexWriter(self.displayer)
        code = self.latexwriter.graph_code()
        print(code)
        pyperclip.copy(code)
        code = self.latexwriter.matrix_code()
        print(code)

        
def display(graph, w=800, h=600, directed=False):
    g = DGraph.get_from_graph(graph)
    GManager(g, directed, w, h)
    
def display_from_adjacency_list(d, w=800, h=600, directed=False):
    g = DGraph.get_from_dict(d)
    GManager(g, directed, w, h)
        
