from modules.gdisplayer import TkNode

class LatexWriter:

    def __init__(self, displayer):
        self.displayer = displayer
        self.wh = displayer.wh
        
    def graph_code(self):
        nodes_code, box = self.nodes_to_latex()
        edges_code = self.edges_to_latex()
        code = "\psset{unit=.025cm,algebraic=true,dimen=middle,dotstyle=o"
        code += ",dotsize=3pt 0,linewidth=1pt,arrowsize=3pt 2,arrowinset=0.25}\n"
        code += "\\begin{pspicture*}(%s,%s)(%s,%s)\n"%box
        code += "\psframe(%s,%s)(%s,%s)\n"%box
        code += nodes_code
        code += edges_code
        code += "\end{pspicture*}"
        return code

        
    def nodes_to_latex(self):
        w, h = self.wh
        s = TkNode.radius
        
        nodes = self.displayer.nodes
        x, y = nodes[0].center
        box = (x, h-y, x, h-y)

        code = ""
        for node in nodes:
            x, y = node.center
            y = h-y
            xmin = min(box[0], x-s-2)
            ymin = min(box[1], y-s-2)
            xmax = max(box[2], x+s+2)
            ymax = max(box[3], y+s+2)
            box = (xmin, ymin, xmax, ymax)
        
            code += "%% Node %s\n"%(node.label)
            code += "\pscircle(%s, %s){%s}\n"%(x, y, s)
            code += "\\rput(%s, %s){%s}\n"%(x, y, node.label)
        return code, box

    def edges_to_latex(self):
        w, h = self.wh
        n = len(self.displayer.nodes)
        edges = self.displayer.edges
        code = ""
        for i in range(n):
            for j in range(n) :
                edge = edges[i][j]
                if edge:
                    x1, y1, x2, y2 = edge.get_coordinates()
                    y1, y2 = h-y1, h-y2
                    code += "%% Edge %s->%s\n"%(edge.start.label, edge.stop.label)
                    arrow = "{->}" if edge.directed else ""
                    code += "\psline%s(%s, %s)(%s, %s)\n"%(arrow, x1, y1, x2, y2)
        return code

    def matrix_code(self):
        m = self.displayer.graph.matrix
        n = len(m)
        code = "\left[\\begin{matrix}\n"
        for i in range(n):
            code += " & ".join([str(mij) for mij in m[i]])
            code += "\\\\\n"
        code += "\end{matrix}\\right]"
        return code
        