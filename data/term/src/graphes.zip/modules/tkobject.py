class TkObject :

    def __init__(self):
        self.obj = None
        self.mouse = None
        

    def draw(self, canvas):
        self.obj = self.create_tk_object(canvas)
        canvas.tag_bind(self.obj, "<Button-1>", lambda ev : self.button_down(canvas, ev))
        canvas.tag_bind(self.obj, "<Button-2>", lambda ev : self.button_down(canvas, ev))
        canvas.tag_bind(self.obj, "<Button-3>", lambda ev : self.button_down(canvas, ev))

        canvas.tag_bind(self.obj, "<ButtonRelease-1>", lambda ev : self.button_up(canvas, ev))
        canvas.tag_bind(self.obj, "<ButtonRelease-2>", lambda ev : self.button_up(canvas, ev))
        canvas.tag_bind(self.obj, "<ButtonRelease-3>", lambda ev : self.button_up(canvas, ev))

        canvas.tag_bind(self.obj, "<Motion>", lambda ev : self._motion(canvas, ev))
        
    def create_tk_object(self, canvas):
        pass
        
    def button_down(self, canvas, event):
        self.mouse = event.x, event.y, event.num

    def button_up(self, canvas, event):
        self.mouse = None
        
    def _motion(self, canvas, event):
        if self.mouse is None :
            return
        mx, my, button = self.mouse
        ex, ey = event.x, event.y
        self.motion(canvas, ex, ey, ex - mx, ey - my, button)
        self.mouse = ex, ey, button
        
    def motion(self, canvas, ex, ey, dx, dy, button):
        pass
        
        
    def latex(self, frame):
        return ""

