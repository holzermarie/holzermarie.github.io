from tkinter import StringVar, Label
from modules.tkobject import TkObject
from random import randint
from modules.tkcontext import TkContext
from modules.algo import compute

class MGraph :
    """ Graph represented by its adjacency matrix """

    def __init__(self, g, directed, listener):
        self.graph = g
        self.directed = directed
        self.listener = listener
        
        self.labels = [ label for label in self.graph.nodes.keys() ]
        self.compute_adjacency_matrix()
        
        compute(self)

    def compute_adjacency_matrix(self):
        n = len(self.labels)
        self.labels.sort()
        label_id = {}
        for i in range(n):
            label_id[self.labels[i]] = i
            
        self.matrix = [ [0 for _ in range(n)] for _ in range(n)]
        for label, node in self.graph.nodes.items():
            i = label_id[label]
            for child in node.get_children() :
                j = label_id[child.label]
                self.matrix[i][j] = 1
                if not self.directed :
                    self.matrix[j][i] = 1
        

                
    def change(self, i, j, val):
        self.matrix[i][j] = val
        node = self.graph.nodes[self.labels[i]]
        child = self.graph.nodes[self.labels[j]]
        if val==0:
            node.children.remove(child)
        else:
            node.children.append(child)

class DGraph :
    """ Graph represented by a dictionary {label(str) : node(DNode)}"""

    def __init__(self):
        self.nodes = {}
        
    def get_from_graph(graph, directed=False):
        """ graph argument must implement get_nodes() -> Node[]
            and Node must implement get_label() and get_children() """
        g = DGraph()
        for node in graph.get_nodes():
            label = node.get_label()
            g.nodes[label] = DNode(label)

        for node in graph.get_nodes():
            label = node.get_label()
            dnode = g.nodes[node.label]
            children = node.get_children()
            for child in children :
                dnode.children.append(g.nodes[child.label])

        return g
    
    def get_from_dict(d, directed=False):
        g = DGraph()
        for label in d.keys():
            if type(label)==str and label.isdigit():
                label = int(label)
            g.nodes[label] = DNode(label)
            
        for label, children_labels in d.items():
            if type(label)==str and label.isdigit():
                label = int(label)
            for child_label in children_labels :
                g.nodes[label].children.append(g.nodes[child_label])

        if not directed:
            DGraph.check(g)
        return g
        
    def check(g):
        for label, node in g.nodes.items():
            for child in node.children :
                if child!=node and node not in child.get_children():
                    msg = "Liste d'adjacence invalide : "
                    msg += "le sommet %s n'apparaît pas dans les voisins de %s"%(node.label, child.label)
                    raise Exception(msg)
                    
class DNode :
    """ Used by DGraph """

    def __init__(self, label):
        self.label = label
        self.children = []
        
    def get_label(self):
        return self.label
        
    def get_children(self):
        return self.children
        