from tkinter import Toplevel, Button, Entry, StringVar, Label, Text, END
from modules.tkobject import TkObject
from modules.tkcontext import TkContext
from random import randint
from math import sqrt, sin, cos, pi

class GDisplayer :

    SNAP = 32

    def __init__(self, graph, tk, w, h):
        self.graph = graph
        self.tk = tk
        self.wh = (w, h)
        self.compute_tk_objects()
        self.layout()
        
    def set_graph(self, g, pos):
        self.graph = g
        self.compute_tk_objects()
        for node in self.nodes:
            label = node.label
            if type(label)==int:
                label = str(label)
            node.center = pos[label]
    
    def compute_tk_objects(self):
        self.nodes = [TkNode(label, self) for label in self.graph.labels]
        n = len(self.nodes)
        self.edges = [[None for _ in range(n)] for _ in range(n)]
        self.entries = [[None for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n) :
                mij = self.graph.matrix[i][j]
                
                active = i<j or self.graph.directed
                self.entries[i][j] = TkMatrixEntry(i, j, mij, active, self)
                
                if mij != 0 and active:
                    start = self.nodes[i]
                    stop = self.nodes[j]
                    self.edges[i][j] = TkEdge(start, stop, self.graph.directed)

    def draw(self):
        canvas = self.tk.graph_canvas
        canvas.delete("all")
        w, h = self.wh
        s = GDisplayer.SNAP
        for i in range(1, w//s+1):
            for j in range(1, h//s+1):
                canvas.create_oval(s*i, s*j, s*i, s*j, outline='#A0A0A0')
        for node in self.nodes :
            node.draw(canvas)
        
        n = len(self.nodes)    
        for i in range(n):
            for j in range(n):
                edge = self.edges[i][j]
                if edge : 
                    edge.draw(canvas)
                    
        canvas = self.tk.matrix_canvas
        canvas.delete("all")
        
        m = TkMatrixEntry.margin
        s = TkMatrixEntry.size
        for i in range(n):
            x = m
            y = m+s*(i+1)
            canvas.create_text(x, y, text=self.nodes[i].label)
            x = m+s*(i+1)
            y = m
            canvas.create_text(x, y, text=self.nodes[i].label)
            
        for i in range(n):
            for j in range(n):
                e = self.entries[i][j]
                e.draw(canvas)
        
    def layout(self):
        n = len(self.nodes)
        w, h = self.wh
        x = w//3
        y = h//2
        r = min(x, y)-100
        k = 0
        s = GDisplayer.SNAP
        for node in self.nodes :
            cx = int(x + r*sin(2*pi*k/n))
            cy = int(y - r*cos(2*pi*k/n))
            node.center = round(cx/s)*s, round(cy/s)*s
            k += 1
            
    def update_edges(self, canvas, node):
        node_idx = self.nodes.index(node)
        n = len(self.nodes)
        edges = [self.edges[node_idx][i] for i in range(n)]
        edges += [self.edges[i][node_idx] for i in range(n)]
        edges = [edge for edge in edges if edge]
        for edge in edges:
            edge.update(canvas)

    def change(self, canvas, i, j, recall=False):
        entry = self.entries[i][j]
        entry.val = 1-entry.val
        canvas.itemconfig(entry.obj, text="%s"%entry.val)
        
        mij = self.graph.change(i, j, entry.val)

        if self.edges[i][j]:
            self.edges[i][j].delete(canvas)

        if entry.val==0:
            self.edges[i][j]=None
        else:
            start = self.nodes[i]
            stop = self.nodes[j]
            self.edges[i][j]=TkEdge(start, stop, self.graph.directed)

        if (not self.graph.directed) and (not recall):
            self.change(canvas, j, i, True)
        self.draw()
            

class TkNode(TkObject):
    
    radius = 16

    def __init__(self, label, owner):
        super().__init__()
        self.label = label
        self.owner = owner
        self.center = (20, 20)
        self.text_obj = None
        
    def create_tk_object(self, canvas):
        x, y = self.center
        r = TkNode.radius
        obj= canvas.create_oval(x-r, y-r, x+r, y+r, fill=TkContext.GREEN, activefill='yellow')
        self.text_obj = canvas.create_text(x, y, text=self.label, state='disable', font=TkContext.FONT)
        return obj

    def motion(self, canvas, ex, ey, dx, dy, button):
        canvas.move(self.obj, dx, dy)
        canvas.move(self.text_obj, dx, dy)
        x1, y1, x2, y2 = canvas.coords(self.obj)
        x, y = (x1+x2)//2, (y1+y2)//2
        self.center = x, y
        self.owner.update_edges(canvas, self)
        
    def button_up(self, canvas, event):
        x, y = self.center
        s = GDisplayer.SNAP
        nx = round(x/s)*s
        ny = round(y/s)*s
        dx, dy = nx-x, ny-y
        
        canvas.move(self.obj, dx, dy)
        canvas.move(self.text_obj, dx, dy)
        self.center = nx, ny
        self.owner.update_edges(canvas, self)

        self.mouse = None
        
class TkEdge(TkObject):
    
    def __init__(self, start, stop, directed):
        super().__init__()
        self.start = start
        self.stop = stop
        self.directed = directed
        self.obj = None
        #self.text_obj = None
        
    def create_tk_object(self, canvas):
        sx, sy, ex, ey = self.get_coordinates()
        if self.directed :
            self.obj = canvas.create_line(sx, sy, ex, ey, width=2, arrow="last")
        else :
            self.obj = canvas.create_line(sx, sy, ex, ey, width=2)
        #self.text_obj = canvas.create_text(x, y, text=self.label, state='disable', font=TkContext.FONT)
        return self.obj
        
    def update(self, canvas):
        sx, sy, ex, ey = self.get_coordinates()
        canvas.coords(self.obj, sx, sy, ex, ey)

    def get_coordinates(self):
        r = TkNode.radius
        px, py = self.start.center
        qx, qy = self.stop.center
        if (px, py)==(qx, qy) :
            return px, py, qx, qy
        pq = sqrt( (qx-px)**2+(qy-py)**2 )
        xp = px + r*(qx-px)/pq
        yp = py + r*(qy-py)/pq
        xq = qx - r*(qx-px)/pq
        yq = qy - r*(qy-py)/pq
        return xp, yp, xq, yq
        
    def delete(self, canvas):
        canvas.delete(self.obj)

class TkMatrixEntry(TkObject):

    margin = 20
    size = 40
    
    def __init__(self, i, j, val, active, listener):
        super().__init__()
        self.i = i
        self.j = j
        self.val = val
        self.active = active
        self.listener = listener
        
    def create_tk_object(self, parent):
        m = TkMatrixEntry.margin
        s = TkMatrixEntry.size
        x, y = m+s*(self.j+1), m+s*(self.i+1)
        state = 'normal'
        if not self.active:
            state = 'disabled'
        return parent.create_text(x, y, text="%s"%self.val, state=state, 
                                  activefill="#F000F0", disabledfill="#A0A0A0")

    def button_down(self, canvas, event):
        super().button_down(canvas, event)
        #self.listener.change(canvas, self.i, self.j)
