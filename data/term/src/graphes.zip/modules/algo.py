def degrees(nodes):
    dmin = 100
    dmax = 0
    dmoy = 0
    for label, node in nodes.items():
        d = len(node.children)
        if d<dmin:
            dmin = d
        if d>dmax:
            dmax = d
        dmoy += d
        
    return dmin, dmax, dmoy/len(nodes)

def mdegrees(m):
    dmin = 100
    dmax = 0
    dmoy = 0
    for line in m:
        print(line)
        d = sum(line)
        if d<dmin:
            dmin = d
        if d>dmax:
            dmax = d
        dmoy += d
        
    return dmin, dmax, dmoy/len(m)
            

def compute(mgraph):
    nodes = mgraph.graph.nodes
    print(degrees(nodes))
    print(mdegrees(mgraph.matrix))
    

def dfs(g, label, visited=[]):
    if label in visited:
        return []
    neighbors = g[label]
    visited.append(label)
    s = [label]
    for neighbor in neighbors:
        s += self.dfs(neighbor, visited)
    return s
