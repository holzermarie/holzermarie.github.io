from tkinter import Tk, Toplevel, Canvas, Button, Text, END, Entry, StringVar, font, ttk, Label, Menu, Frame

class TkContext :

    FONT = None
    GREEN = "#30B030"
    Y_GRAY = "#908040"
    
    def __init__(self, w, h):
        self.window = Tk()
        
        TkContext.FONT = font.Font(family='DejaVu Sans', size=16)    
        
        self.window.geometry("%sx%s+20+20"%(w*3//2, h))
        self.graph_canvas = Canvas(self.window, width=w, height=h, bg="lightgray")
        self.graph_canvas.place(x=0, y=0)
        
        self.matrix_canvas = Canvas(self.window, width=w, height=h)
        self.matrix_canvas.place(x=w, y=0)
        
        self.menu_bar = Menu(self.window)
        self.window["menu"] = self.menu_bar
        
        file_menu = Menu(self.menu_bar)
        self.menu_bar.add_cascade(label="Fichier", menu=file_menu, underline=0)
        
        self.menus = [file_menu]
        
    def mainloop(self):        
        self.window.mainloop()

    def add_menu_command(self, idx, label, command, acc="", shortcut=None):
        menu = self.menus[idx]
        menu.add_command(label=label, command=command, accelerator=acc, underline=0)
        if shortcut:
            self.window.bind_all(shortcut, lambda _ : command())


        
