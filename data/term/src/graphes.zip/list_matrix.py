# FONCTIONS

def get_adjacency_matrix(adj_list):
    # tableau des étiquettes triées
    labels = [label for label in adj_list.keys()]
    labels.sort()
    
    # initialisation de la matrice
    n = len(labels)
    matrix = [[0 for _ in range(n)] for _ in range(n)]
    
    # remplissage
    for i in range(n):
        continue
                
    return matrix


def get_adjacency_list(adj_matrix):
    # tableau des étiquettes des sommets
    n = len(adj_matrix)
    labels = [chr(65 + i) for i in range(n)]
    
    # initialisation de la liste (un dictionnaire)
    dico = {}
    
    # remplissage
    for i in range(n):
        continue
    
    return dico
    
# SCRIPT

# list -> matrix

adj_list = {"A": ["B", "E", "F", "G", "H"],
           "B": ["A", "E", "F", "G", "C", "D"],
           "C": ["B", "G", "H", "D"],
           "D": ["B", "C", "H"],
           "E": ["A", "B", "F"],
           "F": ["A", "E", "B", "G"],
           "G": ["A", "F", "B", "C", "H"],
           "H": ["A", "G", "C", "D"],
           }

adj_matrix = get_adjacency_matrix(adj_list)
for line in adj_matrix :
    print(line)


# matrix -> list

adj_matrix = [[0, 1, 0, 0, 1, 1, 1, 1],
    [1, 0, 1, 1, 1, 1, 1, 0],
    [0, 1, 0, 1, 0, 0, 1, 1],
    [0, 1, 1, 0, 0, 0, 0, 1],
    [1, 1, 0, 0, 0, 1, 0, 0],
    [1, 1, 0, 0, 1, 0, 1, 0],
    [1, 1, 1, 0, 0, 1, 0, 1],
    [1, 0, 1, 1, 0, 0, 1, 0]]

adj_list = get_adjacency_list(adj_matrix)

print("{")
for label, neighbours in adj_list.items():
    print(f'\'{label}\': {neighbours}')
print("}")

