// DÉCLARATION DE VARIABLES
let nombreAuHasard = Math.floor(Math.random()*1000)+1;
console.log(nombreAuHasard);
let nombreEssais = 10;
let tempsRestant = 30;
let chrono = null;
let jeuEnCours = true;

// Récupérer les éléments du DOM dont on va avoir besoin

// - Bouton valider
let validationElement = document.getElementById("boutonValidation");

// - Champ de saisie
let nombreSaisiElement = document.getElementById("champNombreSaisi");

// - Paragraphe contenant la phrase de résultat
let resultatElement = document.getElementById("resultat");

// - Nombre d'essais
// ...

// - Temps restant
// ...

// FONCTIONS

function arreteJeu() {
	jeuEnCours = false;
	clearInterval(chrono); // arrête le chrono
	
	// désactiver les input et button éventuellement ici
}

function gereResultat() {
	let nombreSaisi = parseInt(nombreSaisiElement.value);
	console.log(nombreSaisi);
	
	if (nombreSaisi == nombreAuHasard) {
		resultatElement.innerHTML = "Gagné :)";
	} else if (nombreSaisi > nombreAuHasard) {
		
	}
	else {
		
	}
}

function gereNombreEsssais() {
	nombreEssais -= 1;
	console.log(nombreEssais+" essai(s) restant(s)");
}

function diminueTemps() {
	tempsRestant -= 1;
	console.log(tempsRestant);
	
	if (tempsRestant == 0) {
		// écrire sur la page que le temps est écoulé
		arreteJeu();
	}
	else {
		
	}
}

function valider() {
	if (!jeuEnCours) {
		return; // return tout court renvoie undefined
	}
	
	if (chrono == null) {
		chrono = setInterval(diminueTemps, 1000);
	}
	
	gereResultat();
	gereNombreEsssais();
}


// SCRIPT

validationElement.addEventListener("click", valider);