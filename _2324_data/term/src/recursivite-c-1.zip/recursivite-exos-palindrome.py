# IMPORTS

# FONCTIONS
def est_palindrome_ite(mot):
    taille_mot = len(mot)
    for indice in range(taille_mot//2):
        if mot[indice] != mot[taille_mot-1-indice]:
            return False
    return True

# Autre version
def est_palindrome_ite_compact(mot):
    return mot == mot[::-1]

def est_palindrome(mot):
    if len(mot) <= 1: # si le mot est vide ou n'a qu'un seul caractère, c'est un palindrome
        return True
    
    if mot[0] == mot[-1]: # comparaison du premier et du dernier caractère
        return est_palindrome(mot[1:-1]) # on rappelle la fonction sur le mot sans ses lettres extrêmes
    
    return False

# SCRIPT
# batterie de tests pour vérifier nos fonctions (ne pas oublier de tester plusieurs cas dont les cas de base !)
assert est_palindrome_ite("")
assert est_palindrome_ite("z")
assert est_palindrome_ite("été")
assert est_palindrome_ite("radar")
assert not est_palindrome_ite("Radar")
assert not est_palindrome_ite("spaghetti")


assert est_palindrome_ite_compact("")
assert est_palindrome_ite_compact("z")
assert est_palindrome_ite_compact("été")
assert est_palindrome_ite_compact("radar")
assert not est_palindrome_ite_compact("Radar")
assert not est_palindrome_ite_compact("spaghetti")


assert est_palindrome("")
assert est_palindrome("z")
assert est_palindrome("été")
assert est_palindrome("radar")
assert not est_palindrome("Radar")
assert not est_palindrome("spaghetti")